# Jarvis Agent: आपकी आवाज़ से चलने वाली Multi-Agent टीम

## Agents और उनकी फ़ाइलें
| Agent | फ़ाइल | काम |
|---|---|---|
| Orchestrator (दिमाग) | Orchestrator.kt, Claude.kt, Dispatch.kt | बात समझकर सही tool चलाता है |
| 1. Conversation | Speaker.kt, AgentService.kt | सुनता और हिंदी में बोलता है |
| 2. Device Control | DeviceAgent.kt, JarvisAccessibilityService.kt | call, SMS, WhatsApp, app, like/tap, type, scroll, screen lock, volume |
| 3. Security | SecurityAgent.kt, ConfirmActivity.kt | wake word, fingerprint/PIN, 3 गलत कोशिश पर lock |
| 4. Coding | CodingAgent.kt | code लिखकर workspace में सेव करता है |
| 5. Self-Upgrade | SelfUpgradeAgent.kt, Plugins.kt | आपकी मंज़ूरी से नया feature (macro plugin) जोड़ता है |
| 6. Kill-Switch | KillSwitch.kt | "स्टॉप" / "रुको" कहते ही सब रद्द |

## Step by Step (चलाने का तरीका)
1. **Android Studio** (Koala या नया) install करें।
2. `File > Open` से `JarvisAgent` folder खोलें, Gradle sync पूरा होने दें।
3. **API key** लें: console.anthropic.com से (यह Claude का दिमाग है; bिना key के agent जवाब नहीं देगा)।
4. फ़ोन में **Developer options > USB debugging** चालू करें, USB से जोड़ें, ▶ Run दबाएँ।
5. App खुलने पर:
   - API key और wake word (जैसे "जार्विस") डालकर **सेव करें**
   - **1. Permissions दें** (mic, call, SMS, contacts, notification)
   - **2. Overlay permission दें**
   - **3. Accessibility चालू करें** > "Jarvis Agent" ढूँढें > ON करें
     (अगर Android "restricted setting" कहे: Settings > Apps > Jarvis Agent > ⋮ > *Allow restricted settings*)
   - Battery settings में Jarvis को "Unrestricted" करें
6. **▶ Agent शुरू करें** दबाएँ। Notification में "Jarvis सुन रहा है" दिखेगा।
7. बोलकर आज़माएँ:
   - "जार्विस, YouTube खोलो"
   - "जार्विस, मम्मी को कॉल करो"
   - "जार्विस, स्क्रीन लॉक कर दो"
   - "जार्विस, राहुल को WhatsApp करो कि मैं देर से आऊँगा" (fingerprint माँगेगा)
   - "जार्विस, एक Python calculator लिखकर सेव करो"
   - "जार्विस, नया feature जोड़ो: सुबह बोलने पर WhatsApp खोलकर नोटिफ़िकेशन दिखाओ" (fingerprint माँगेगा)
   - **"स्टॉप"** कभी भी बोलें, सब रुक जाएगा (notification का STOP बटन भी है)

## ईमानदार सीमाएँ (ज़रूर पढ़ें)
- **यह code compile/test करके नहीं दिया गया है।** मेरे पास Android SDK नहीं है। पहली बार build में छोटी errors आ सकती हैं। Error यहाँ चिपकाइए, मैं ठीक कर दूँगा।
- **"सिर्फ़ मेरी आवाज़" (speaker verification) शामिल नहीं है।** Android का SpeechRecognizer raw audio नहीं देता। इसके लिए AudioRecord + Picovoice Eagle जोड़ना होगा। अभी सुरक्षा wake word + fingerprint/PIN पर टिकी है, और रिकॉर्डिंग चलाने वाला wake word बोलकर साधारण काम करवा सकता है। इसीलिए SMS/WhatsApp/नया feature पर biometric ज़रूरी रखा है। `Config.sensitiveTools` में और काम जोड़ सकते हैं।
- **Self-Upgrade** का मतलब है मौजूदा tools को जोड़कर नए "macro" बनाना। Android में चलता app अपना APK नहीं बदल सकता। असली source-code बदलाव के लिए Coding Agent से code लिखवाकर Android Studio में खुद जोड़ें।
- **WhatsApp "Send" बटन** अलग phone/भाषा में नाम बदलने पर न मिले तो `DeviceAgent.whatsapp` में लेबल जोड़ें। "Like" भी इसी तरह screen के label से दबता है, इसलिए हर app में 100% नहीं चलेगा।
- STOP सभी **agent tasks** रोकता है, पर शुरू हो चुकी phone call अपने-आप नहीं काटता।
- पूरी समय mic चालू रहने से battery ज़्यादा खर्च होगी। Speech recognition Google की service से होती है।
- Play Store पर SMS/Accessibility की सख़्त नीतियाँ हैं, इसलिए सिर्फ़ निजी इस्तेमाल (sideload) के लिए बनाया गया है।
- API key फ़ोन में साधारण storage में रहती है। किसी और को app/phone न दें।
