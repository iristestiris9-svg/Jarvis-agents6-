package com.myagent.jarvis

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.UUID

/** Agent 1: Conversation Agent की आवाज़ (TTS) */
object Speaker {
    private var tts: TextToSpeech? = null
    fun init(c: Context) {
        tts = TextToSpeech(c) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
    }
    fun say(t: String) { tts?.speak(t, TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString()) }
    fun stop() { tts?.stop() }
}
