package com.myagent.jarvis

import kotlinx.coroutines.Job

/** Agent 6: Kill-Switch. LLM पर निर्भर नहीं, सीधा keyword check। */
object KillSwitch {
    @Volatile var job: Job? = null
    private var lastStop = 0L

    fun isStopWord(t: String): Boolean {
        val l = t.lowercase().trim()
        val strong = listOf("स्टॉप", "स्टाप", "stop", "रुको", "ruko")
        val weak = listOf("बंद करो", "बंद कर दो", "band karo")
        return strong.any { l.contains(it) } ||
            (l.split(" ").size <= 3 && weak.any { l.contains(it) })
    }

    fun stopAll() {
        job?.cancel()          // चल रहे सभी agent tasks रद्द
        Speaker.stop()         // बोलना बंद
        val now = System.currentTimeMillis()
        if (now - lastStop > 2000) { lastStop = now; Speaker.say("रुक गया") }
    }
}
