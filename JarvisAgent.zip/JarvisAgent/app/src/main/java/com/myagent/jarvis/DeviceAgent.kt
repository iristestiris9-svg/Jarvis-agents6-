package com.myagent.jarvis

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.accessibilityservice.AccessibilityService
import kotlinx.coroutines.delay
import java.net.URLEncoder

/** Agent 2: Device Control Agent */
object DeviceAgent {
    private val ctx get() = Config.app
    private val launcher: Context get() = JarvisAccessibilityService.instance ?: ctx
    private val acc get() = JarvisAccessibilityService.instance

    fun resolveNumber(q: String): String? {
        if (q.count { it.isDigit() } >= 5) return q.filter { it.isDigit() || it == '+' }
        return try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$q%"), null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: SecurityException) { null }
    }

    fun openApp(name: String): String {
        val pm = ctx.packageManager
        val app = pm.getInstalledApplications(0)
            .firstOrNull { pm.getApplicationLabel(it).toString().contains(name, true) }
            ?: return "$name नाम का app नहीं मिला"
        val i = pm.getLaunchIntentForPackage(app.packageName) ?: return "यह app खुल नहीं सकता"
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launcher.startActivity(i)
        return "$name खोल दिया"
    }

    fun call(to: String): String {
        val n = resolveNumber(to) ?: return "$to का नंबर नहीं मिला"
        launcher.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "$to को कॉल लगा रहा हूँ"
    }

    fun sms(to: String, text: String): String {
        val n = resolveNumber(to) ?: return "$to का नंबर नहीं मिला"
        val sm = if (android.os.Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
        sm.sendMultipartTextMessage(n, null, sm.divideMessage(text), null, null)
        return "SMS भेज दिया"
    }

    suspend fun whatsapp(to: String, text: String): String {
        val a = acc ?: return "Accessibility सेवा चालू नहीं है"
        var n = resolveNumber(to) ?: return "$to का नंबर नहीं मिला"
        n = n.filter { it.isDigit() }
        if (n.length == 10) n = Config.countryCode + n
        val url = "https://wa.me/$n?text=" + URLEncoder.encode(text, "UTF-8")
        launcher.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        delay(3500)
        return if (a.clickText("Send") || a.clickText("भेजें")) "WhatsApp message भेज दिया"
        else "WhatsApp खुला, पर Send बटन नहीं मिला"
    }

    fun phoneAction(action: String): String {
        val a = acc ?: return "Accessibility सेवा चालू नहीं है"
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (action) {
            "lock_screen" -> a.lockScreen()
            "home" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "back" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "recents" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "notifications" -> a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "scroll_down" -> a.swipe(true)
            "scroll_up" -> a.swipe(false)
            "volume_up" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "volume_down" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            else -> return "अज्ञात action"
        }
        return "$action हो गया"
    }

    fun tap(text: String): String {
        val a = acc ?: return "Accessibility सेवा चालू नहीं है"
        return if (a.clickText(text)) "'$text' दबा दिया" else "'$text' स्क्रीन पर नहीं मिला"
    }

    fun type(text: String): String {
        val a = acc ?: return "Accessibility सेवा चालू नहीं है"
        return if (a.typeText(text)) "लिख दिया" else "कोई text box चुना हुआ नहीं है"
    }

    fun readScreen(): String = acc?.readScreen() ?: "Accessibility सेवा चालू नहीं है"
}
