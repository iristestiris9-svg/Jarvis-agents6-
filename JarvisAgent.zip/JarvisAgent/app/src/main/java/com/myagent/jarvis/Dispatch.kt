package com.myagent.jarvis

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONObject

/** हर tool call यहीं से गुज़रता है: STOP check + Security check */
object Dispatch {
    suspend fun execute(name: String, input: JSONObject): String {
        currentCoroutineContext().ensureActive()
        if (SecurityAgent.isSensitive(name) &&
            !SecurityAgent.confirm(Config.app, "$name: ${input.toString().take(80)}")
        ) return "यूज़र ने मंज़ूरी नहीं दी, काम रद्द"
        return try {
            when {
                name == "open_app" -> DeviceAgent.openApp(input.getString("name"))
                name == "make_call" -> DeviceAgent.call(input.getString("to"))
                name == "send_sms" -> DeviceAgent.sms(input.getString("to"), input.getString("text"))
                name == "send_whatsapp" -> DeviceAgent.whatsapp(input.getString("to"), input.getString("text"))
                name == "phone_action" -> DeviceAgent.phoneAction(input.getString("action"))
                name == "tap_text" -> DeviceAgent.tap(input.getString("text"))
                name == "type_text" -> DeviceAgent.type(input.getString("text"))
                name == "read_screen" -> DeviceAgent.readScreen()
                name == "write_code" -> CodingAgent.write(input.getString("filename"), input.getString("code"))
                name == "list_code" -> CodingAgent.list()
                name == "add_feature" -> SelfUpgradeAgent.add(input)
                name.startsWith("plugin_") -> Plugins.run(name.removePrefix("plugin_"))
                else -> "अज्ञात tool: $name"
            }
        } catch (e: kotlinx.coroutines.CancellationException) { throw e
        } catch (e: Exception) { "त्रुटि: ${e.message}" }
    }
}
