package com.myagent.jarvis

import android.content.Context

/**
 * Agent 3: Security Agent
 * - Wake word के बिना कोई आवाज़ ignore
 * - संवेदनशील काम पर fingerprint/PIN
 * - 3 बार गलत पुष्टि पर फ़ोन lock
 * NOTE: असली "सिर्फ़ मेरी आवाज़" (speaker verification) के लिए README देखें।
 */
object SecurityAgent {
    private var failed = 0

    fun extractCommand(text: String): String? {
        val l = text.lowercase()
        val words = listOf(Config.wakeWord.lowercase(), "jarvis", "जार्विस", "जारविस", "जर्विस")
        for (w in words) {
            val i = l.indexOf(w)
            if (i >= 0) {
                val cmd = text.substring(i + w.length).trim(' ', ',', '।', '.')
                if (cmd.isEmpty()) { Speaker.say("जी, बोलिए"); return null }
                return cmd
            }
        }
        return null
    }

    fun isSensitive(tool: String) = tool in Config.sensitiveTools

    suspend fun confirm(ctx: Context, reason: String): Boolean {
        Speaker.say("पुष्टि के लिए fingerprint या PIN दें")
        val ok = ConfirmActivity.ask(ctx, reason)
        if (ok) failed = 0 else {
            failed++
            if (failed >= 3) {
                failed = 0
                JarvisAccessibilityService.instance?.lockScreen()
                Speaker.say("संदिग्ध कोशिश, फ़ोन लॉक कर दिया")
            }
        }
        return ok
    }
}
