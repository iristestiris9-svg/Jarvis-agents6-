package com.myagent.jarvis

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        val key = EditText(this).apply { hint = "Anthropic API Key"; setText(Config.apiKey) }
        val wake = EditText(this).apply { hint = "Wake word (जैसे: जार्विस)"; setText(Config.wakeWord) }
        root.addView(key); root.addView(wake)
        fun btn(t: String, f: () -> Unit) {
            root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        }
        btn("सेव करें") {
            Config.apiKey = key.text.toString().trim()
            Config.wakeWord = wake.text.toString().trim().ifEmpty { "जार्विस" }
            Toast.makeText(this, "सेव हो गया", Toast.LENGTH_SHORT).show()
        }
        btn("1. Permissions दें") {
            ActivityCompat.requestPermissions(this, arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS,
                Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Overlay permission दें") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Accessibility चालू करें") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("▶ Agent शुरू करें") {
            ContextCompat.startForegroundService(this, Intent(this, AgentService::class.java))
        }
        btn("⏹ STOP / बंद करें") {
            KillSwitch.stopAll(); stopService(Intent(this, AgentService::class.java))
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
