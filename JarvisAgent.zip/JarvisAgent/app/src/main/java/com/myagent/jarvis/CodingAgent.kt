package com.myagent.jarvis

import java.io.File

/** Agent 4: Coding Agent. Code सिर्फ़ app की workspace folder में सेव होता है (चलाया नहीं जाता)। */
object CodingAgent {
    private val dir get() = File(Config.app.filesDir, "workspace").apply { mkdirs() }

    fun write(filename: String, code: String): String {
        val f = File(dir, File(filename).name)   // path traversal रोकने के लिए सिर्फ़ file name
        f.writeText(code)
        return "code सेव हुआ: ${f.absolutePath}"
    }

    fun list(): String = dir.list()?.joinToString(", ")?.ifEmpty { "कोई file नहीं" } ?: "कोई file नहीं"
}
