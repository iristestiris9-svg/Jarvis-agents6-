package com.myagent.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeout

class ConfirmActivity : AppCompatActivity() {
    companion object {
        @Volatile var pending: CompletableDeferred<Boolean>? = null
        suspend fun ask(ctx: Context, reason: String): Boolean {
            val d = CompletableDeferred<Boolean>()
            pending = d
            val launcher: Context = JarvisAccessibilityService.instance ?: ctx
            launcher.startActivity(
                Intent(ctx, ConfirmActivity::class.java)
                    .putExtra("reason", reason)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return try { withTimeout(30_000) { d.await() } } catch (e: Exception) { false } finally { pending = null }
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) {
                pending?.complete(true); finish()
            }
            override fun onAuthenticationError(code: Int, msg: CharSequence) {
                pending?.complete(false); finish()
            }
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), cb)
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Jarvis: पुष्टि करें")
            .setSubtitle(intent.getStringExtra("reason") ?: "")
            .setAllowedAuthenticators(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)
            .build()
        prompt.authenticate(info)
    }

    override fun onDestroy() {
        pending?.complete(false)
        super.onDestroy()
    }
}
