package com.myagent.jarvis

import android.app.Application

class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Config.app = applicationContext
        Speaker.init(applicationContext)
        Plugins.init(applicationContext)
    }
}
