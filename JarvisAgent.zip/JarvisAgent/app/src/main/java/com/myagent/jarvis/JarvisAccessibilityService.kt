package com.myagent.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Device Control का असली हाथ: tap, type, scroll, lock */
class JarvisAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: JarvisAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    fun lockScreen() = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)

    fun clickText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var x: AccessibilityNodeInfo? = n
            while (x != null) {
                if (x.isClickable) { x.performAction(AccessibilityNodeInfo.ACTION_CLICK); return true }
                x = x.parent
            }
        }
        return false
    }

    fun typeText(t: String): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle().putCharSequenceReturn(t)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun Bundle.putCharSequenceReturn(t: String): Bundle {
        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t); return this
    }

    fun readScreen(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 3000) return
            n.text?.let { sb.append(it).append(" | ") }
            n.contentDescription?.let { sb.append(it).append(" | ") }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return sb.toString().ifEmpty { "स्क्रीन पर कुछ पढ़ने लायक नहीं मिला" }
    }

    fun swipe(down: Boolean) {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val y1 = m.heightPixels * (if (down) 0.7f else 0.3f)
        val y2 = m.heightPixels * (if (down) 0.3f else 0.7f)
        val p = Path().apply { moveTo(x, y1); lineTo(x, y2) }
        dispatchGesture(
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build(),
            null, null
        )
    }
}
