package com.myagent.jarvis

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** हमेशा सुनता है। STOP सबसे पहले जाँचा जाता है (बोलते-बोलते भी, partial results पर)। */
class AgentService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())
    private var dead = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP_ALL") { KillSwitch.stopAll(); return START_STICKY }
        val ch = "jarvis"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, AgentService::class.java).setAction("STOP_ALL"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, ch)
            .setContentTitle("Jarvis सुन रहा है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(0, "STOP", stopPi).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (recognizer == null) listen()
        return START_STICKY
    }

    private fun first(b: Bundle?) =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""

    private fun listen() {
        if (dead) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onPartialResults(b: Bundle?) {
                    if (KillSwitch.isStopWord(first(b))) KillSwitch.stopAll()
                }
                override fun onResults(b: Bundle?) { handle(first(b)); restart() }
                override fun onError(e: Int) { restart() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(r: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        recognizer?.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        )
    }

    private fun restart() { main.postDelayed({ listen() }, 300) }

    private fun handle(text: String) {
        if (text.isBlank()) return
        if (KillSwitch.isStopWord(text)) { KillSwitch.stopAll(); return }       // 1) Kill-Switch
        val cmd = SecurityAgent.extractCommand(text) ?: return                  // 2) Security
        Orchestrator.run(cmd)                                                   // 3) Orchestrator
    }

    override fun onDestroy() {
        dead = true
        recognizer?.destroy()
        KillSwitch.stopAll()
        super.onDestroy()
    }
}
