package com.myagent.jarvis

import android.content.Context
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** नए features = सुरक्षित "macro plugins" (tool calls की सूची)। कोई अनजाना code नहीं चलता। */
object Plugins {
    private lateinit var dir: File
    fun init(c: Context) { dir = File(c.filesDir, "plugins").apply { mkdirs() } }

    fun clean(n: String) = n.lowercase().replace(Regex("[^a-z0-9_]"), "_").take(40)

    fun save(name: String, desc: String, steps: JSONArray) {
        File(dir, clean(name) + ".json").writeText(
            JSONObject().put("name", clean(name)).put("description", desc).put("steps", steps).toString()
        )
    }

    fun toolDefs(): List<JSONObject> = (dir.listFiles() ?: emptyArray()).mapNotNull {
        try {
            val o = JSONObject(it.readText())
            JSONObject().put("name", "plugin_" + o.getString("name"))
                .put("description", "User-added feature: " + o.getString("description"))
                .put("input_schema", JSONObject().put("type", "object").put("properties", JSONObject()))
        } catch (e: Exception) { null }
    }

    suspend fun run(name: String): String {
        val f = File(dir, clean(name) + ".json")
        if (!f.exists()) return "plugin नहीं मिला"
        val steps = JSONObject(f.readText()).getJSONArray("steps")
        val log = StringBuilder()
        for (i in 0 until steps.length()) {
            currentCoroutineContext().ensureActive()      // STOP यहाँ भी काम करता है
            val s = steps.getJSONObject(i)
            log.append(Dispatch.execute(s.getString("tool"), s.getJSONObject("input"))).append("; ")
        }
        return log.toString()
    }
}
