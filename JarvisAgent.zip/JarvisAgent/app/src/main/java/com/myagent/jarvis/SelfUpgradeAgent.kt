package com.myagent.jarvis

import org.json.JSONObject

/** Agent 5: Self-Upgrade Agent. सिर्फ़ आपकी biometric मंज़ूरी के बाद (Dispatch में चेक होता है)। */
object SelfUpgradeAgent {
    private val allowed = setOf(
        "open_app", "make_call", "send_sms", "send_whatsapp", "phone_action",
        "tap_text", "type_text", "read_screen", "write_code"
    )

    fun add(input: JSONObject): String {
        val name = input.getString("name")
        val steps = input.getJSONArray("steps")
        for (i in 0 until steps.length()) {
            val t = steps.getJSONObject(i).getString("tool")
            if (t !in allowed) return "step में '$t' की अनुमति नहीं है"
        }
        Plugins.save(name, input.getString("description"), steps)
        return "नया feature जुड़ गया: plugin_${Plugins.clean(name)}"
    }
}
