package com.myagent.jarvis

import android.content.Context

object Config {
    lateinit var app: Context
    private fun p() = app.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var apiKey: String
        get() = p().getString("key", "") ?: ""
        set(v) { p().edit().putString("key", v).apply() }
    var wakeWord: String
        get() = p().getString("wake", "जार्विस") ?: "जार्विस"
        set(v) { p().edit().putString("wake", v).apply() }
    var model: String
        get() = p().getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5"
        set(v) { p().edit().putString("model", v).apply() }
    var countryCode: String
        get() = p().getString("cc", "91") ?: "91"
        set(v) { p().edit().putString("cc", v).apply() }

    // इन कामों से पहले fingerprint/PIN की पुष्टि ज़रूरी है
    val sensitiveTools = setOf("send_sms", "send_whatsapp", "add_feature")
}
