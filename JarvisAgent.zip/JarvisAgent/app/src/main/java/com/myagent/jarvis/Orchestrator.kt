package com.myagent.jarvis

import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject

/** मुख्य दिमाग: आपकी बात समझकर सही tool/agent चलाता है */
object Orchestrator {
    private val history = JSONArray()

    private fun t(name: String, desc: String, vararg props: Pair<String, String>): JSONObject {
        val p = JSONObject()
        props.forEach { p.put(it.first, JSONObject().put("type", "string").put("description", it.second)) }
        return JSONObject().put("name", name).put("description", desc).put(
            "input_schema",
            JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(props.map { it.first }))
        )
    }

    private fun tools(): JSONArray {
        val a = JSONArray()
        a.put(t("open_app", "Open an installed app by name", "name" to "app name"))
        a.put(t("make_call", "Call a contact name or number", "to" to "contact name or number"))
        a.put(t("send_sms", "Send an SMS", "to" to "contact or number", "text" to "message"))
        a.put(t("send_whatsapp", "Send a WhatsApp message", "to" to "contact or number", "text" to "message"))
        a.put(t("phone_action", "One of: lock_screen, home, back, recents, notifications, scroll_down, scroll_up, volume_up, volume_down", "action" to "the action"))
        a.put(t("tap_text", "Tap an on-screen element by its text/label (e.g. Like, Follow)", "text" to "label"))
        a.put(t("type_text", "Type text into the focused input field", "text" to "text"))
        a.put(t("read_screen", "Read the visible text on screen"))
        a.put(t("write_code", "Save code into the workspace folder", "filename" to "file name", "code" to "full code"))
        a.put(t("list_code", "List saved code files"))
        a.put(
            JSONObject().put("name", "add_feature")
                .put("description", "Add a new reusable feature (macro of existing tools). Only when owner asks. Needs owner's biometric approval.")
                .put("input_schema", JSONObject(
                    """{"type":"object","properties":{
                    "name":{"type":"string"},"description":{"type":"string"},
                    "steps":{"type":"array","items":{"type":"object","properties":{
                    "tool":{"type":"string"},"input":{"type":"object"}},"required":["tool","input"]}}},
                    "required":["name","description","steps"]}"""
                ))
        )
        Plugins.toolDefs().forEach { a.put(it) }
        return a
    }

    fun run(cmd: String) {
        KillSwitch.job?.cancel()
        KillSwitch.job = CoroutineScope(Dispatchers.Default + SupervisorJob()).launch {
            try { loop(cmd) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { Speaker.say("गड़बड़ हुई: ${e.message}") }
        }
    }

    private suspend fun loop(cmd: String) {
        if (history.length() > 30) while (history.length() > 0) history.remove(0)
        history.put(JSONObject().put("role", "user").put("content", cmd))
        repeat(8) {
            val resp = withContext(Dispatchers.IO) { Claude.call(history, tools()) }
            currentCoroutineContext().ensureActive()
            val content = resp.getJSONArray("content")
            history.put(JSONObject().put("role", "assistant").put("content", content))
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                when (b.getString("type")) {
                    "text" -> Speaker.say(b.getString("text"))
                    "tool_use" -> {
                        val out = Dispatch.execute(b.getString("name"), b.getJSONObject("input"))
                        results.put(JSONObject().put("type", "tool_result")
                            .put("tool_use_id", b.getString("id")).put("content", out))
                    }
                }
            }
            if (results.length() == 0) return
            history.put(JSONObject().put("role", "user").put("content", results))
        }
    }
}
